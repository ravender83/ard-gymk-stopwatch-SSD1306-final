/*
 * Fixed width font for numbers that looks like LCD panel digits
 * This font including pad pixels, will render 14x24 pixels on the display 
 *
 * This font is very useful when using overstrike as all characters & numbers
 * are all the same width.
 *
 * This font is not a complete character set. The font only contains
 * the characters: '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7', '9', ':'
 *
 * This font is nice for certain applications like clocks, signed values or decimal point values.
 *
 */


GLCDFONTDECL(lcdnums4x32dwu) =
{
  0x0, 0x0,	// size of zero indicates fixed width font
    2,		// width  (will be 14 with pad pixel on right)
    32,		// height (will be 24 with pad pixel on bottom)
    ':',	// first char
    1,		// char count

0x00, 0x00, 0x0F, 0x0F, 0x78, 0x78, 0x00, 0x00 // :

};
